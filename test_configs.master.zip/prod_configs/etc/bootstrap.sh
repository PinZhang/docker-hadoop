#!/bin/bash

sed -i '/^Port 22/ s:.*:Port 8002:' /etc/ssh/sshd_config

/usr/sbin/sshd

# echo "10.240.24.186 slave" >> /etc/hosts
# echo "127.0.0.1 master" >> /etc/hosts

$HADOOP_PREFIX/sbin/start-dfs.sh
$HADOOP_PREFIX/sbin/start-yarn.sh

if [[ $1 == "-d" ]]; then
  while true; do sleep 1000; done
fi

if [[ $1 == "-bash" ]]; then
  /bin/bash
fi

